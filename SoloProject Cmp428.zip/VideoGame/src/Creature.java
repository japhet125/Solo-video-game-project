public class Creature extends Sprite
{
	private static String[] pose = {"Dn", "Up", "Lt", "Rt"};

	
	public Creature(int x, int y)
	{
		super("F", pose, x, y, 3, 15);
	}

}


