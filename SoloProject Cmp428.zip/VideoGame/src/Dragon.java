
public class Dragon extends Sprite
{
	private static String[] pose = {"Dn", "Up", "Lt", "Rt"};

	
	public Dragon(int x, int y)
	{
		super("H", pose, x, y, 3, 15);
	}

}


