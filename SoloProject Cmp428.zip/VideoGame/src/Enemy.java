public class Enemy extends Sprite
{
	private static String[] pose = {"Dn", "Up", "Lt", "Rt"};

	
	public Enemy(int x, int y)
	{
		super("G", pose, x, y, 8, 15);
	}

}

