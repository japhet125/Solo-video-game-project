
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;


public class GameB extends GameBase
{
	
	Zone1 zone1 = new Zone1(pressing);
	Zone2 zone2 = new Zone2(pressing);
	Zone3 zone3 = new Zone3(pressing);
	
	
	
	
	
	public void init()
	{
		super.init();

		Zone.setCurrentZoneTo(1);
	}
	
	public void inGameLoop()
	{
		
		
		Zone.inGameLoopStatic();	
		
	}
	
	
	
	public void paint(Graphics pen)
	{
		Zone.paintStatic(pen);
		//update(pen);
		
		
		
	}


	

	

	
}