public class Soldier extends Sprite
{
	private static String[] pose = {"Dn", "Up", "Lt", "Rt"};

	
	public Soldier(int x, int y)
	{
		super("P", pose, x, y, 4, 15);
	}

}

