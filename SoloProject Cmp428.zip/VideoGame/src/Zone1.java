
import java.awt.Graphics;

public class Zone1 extends Zone
{
	ImageLayer t = new ImageLayer("field.jpg", 0, 0, 1);
	
	
	public Zone1(boolean[] pressing)
	{
		super(pressing);
	}
	
	public void inGameLoop()
	{
		
		
		if(pressing[UP]) soldier.goUP(10);
		if(pressing[DN]) soldier.goDN(10);

		if(pressing[LT]) soldier.goLT(10);
		if(pressing[RT]) soldier.goRT(10);
		
		
		enemy.chase(soldier, 1);
		//creature.chase(soldier, 1);
		
		for(int i = 0; i < wall.length; i++)
		{
			if(soldier.overlaps(wall[i]))    soldier.pushedOutOf(wall[i]);
			if( enemy.overlaps(wall[i]))     enemy.pushedOutOf(wall[i]);
			//if( creature.overlaps(wall[i]))     creature.pushedOutOf(wall[i]);
			
			
			
		}
		//if(soldier.overlaps(enemy))    soldier.pushedOutOf(enemy);
		//soldier.pushbackRightFrom(enemy);
		
		

				
		soldier.move();
		
		
		
		
		if(soldier.x > 1000)
		{
			Zone.zone[0] = Zone.zone[2];
			
			soldier.x = 15;
			enemy.x = 10;
			//creature.x = 6;
		}
				
	}
	
	public void paint(Graphics pen)
	{
		t.draw(pen);
		//creature.draw(pen);
		soldier.draw(pen);
		enemy.draw(pen);
		
	}

}